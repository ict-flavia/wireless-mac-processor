**********************************************
**************** USRP-TRACKER ****************
**********************************************
START PROGRAM :

	launch loop_do_capture in background from shell with
		sudo ./loop_do_capture <channel>

	launch UsrpTracker from MATLAB


**********************************************
**********************************************
		
